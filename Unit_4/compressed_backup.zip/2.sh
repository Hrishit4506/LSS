#!/bin/bash

echo "========================================"
echo "🔍 Full Disk Space Usage Summary"
echo "========================================"

# Display disk usage summary in human-readable format
df -hT

echo ""
echo "========================================"
echo "✅ Summary Complete"
echo "========================================"
